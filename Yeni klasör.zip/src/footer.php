<?php
// src/footer.php
?>
  </main>
  <footer class="text-center py-3 mt-5 small text-white bg-dark shadow-sm" style="letter-spacing:0.01em;">
    &copy; <?= date('Y') ?> Cafe POS
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
