<?php
// public/index.php
require __DIR__ . '/../config/init.php';

echo '<h1>Cafe POS Sistemi çalışıyor!</h1>';
